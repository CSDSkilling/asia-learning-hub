# Trainer Guide – Expected Results (Answer Key)

Use this guide to rehearse the demo and to validate Copilot's outputs. Copilot's wording will vary; the **numbers below are calculated directly from the data files**.

## Dataset at a glance

| Measure | Value |
|---|---|
| Total tickets (October 2026) | 1,505 |
| Closed / Open at month end | 1,456 / 49 |
| Priority mix | P1 5 · P2 143 · P3 801 · P4 556 |
| Change vs September total (1,412) | +6.6% |

## SLA compliance by priority

Resolution compliance is calculated on **Closed** tickets only.

| Priority | Response SLA | Resolution SLA | vs 95% target |
|---|---|---|---|
| P1 | 100.0% | 80.0% (4/5) | ❌ Missed |
| P2 | 97.9% | 85.2% (121/142) | ❌ Missed |
| P3 | 97.3% | 98.3% (758/771) | ✅ Met |
| P4 | 98.0% | 98.3% (529/538) | ✅ Met |
| **All** | **97.6%** | **97.0%** | ✅ Met overall |

**Service credits (Schedule 3, section 3.5):** P1 and P2 resolution both missed → 2% + 2% = **4% of the monthly service charge**. P2 was 95.8% in September, so this is **not** two consecutive misses and no formal Service Improvement Plan is contractually triggered — a good discussion point.

**P2 without the outage week:** excluding Network Operations P2 tickets opened 14–20 Oct, P2 compliance would be **94.2%** — the outage explains most of the miss.

## Resolution SLA breaches

| Assignment Group | Breaches |
|---|---|
| Network Operations | 21 |
| Desktop Support L2 | 9 |
| Store Systems Support | 6 |
| Identity & Access | 4 |
| Service Desk L1 | 3 |
| Application Support | 1 |

| Week | Breaches |
|---|---|
| 2026-09-28/2026-10-04 | 4 |
| 2026-10-05/2026-10-11 | 7 |
| 2026-10-12/2026-10-18 | 22 |
| 2026-10-19/2026-10-25 | 10 |
| 2026-10-26/2026-11-01 | 1 |

## Experience KPIs

| KPI | October | Target | Status | September |
|---|---|---|---|---|
| First Contact Resolution | 58.1% | ≥ 65% | ❌ Missed | 61.2% |
| CSAT (average, 571 responses) | 4.3 | ≥ 4.2 | ✅ Met | 4.31 |
| Reopen rate | 3.5% | ≤ 5% | ✅ Met | 3.1% |
| Backlog at month end | 49 | ≤ 60 | ✅ Met | 46 |

CSAT by shift: Weekday Day **4.44** · Weekday Night **4.34** · Weekend **3.69**

Highest reopen rates: Software Install **15.0%** · POS Terminal **6.9%** · Store Connectivity **6.7%** · Access Request **5.6%**

## Volume

| Category | Tickets |
|---|---|
| Access & Identity | 495 |
| Software | 254 |
| Network | 216 |
| Email & Collaboration | 171 |
| Hardware | 158 |
| Store Systems | 135 |
| Printing | 76 |

- Password Reset + Account Unlock: **398 (26.4%)**
- Channel: Portal 641 (+19.1% vs Sept 538) · Phone 441 (-12.2% vs Sept 502) · Email 232 · Chat 191

## The story to tell

1. **Healthy core service:** overall SLAs above 95%, backlog under control, reopen rate within target.
2. **One bad week:** the 14 Oct SD-WAN firmware outage (INC-P1-1042) breached the P1 SLA and caused a wave of P2 store connectivity tickets → P1 and P2 service credits.
3. **Avoidable:** the root cause links back to overdue September action **A-0904** (CAB for firmware changes). Copilot Chat can surface this link in Step 1.
4. **Opportunities:** shift-left password reset (~a quarter of demand, and the CIO is chasing A-0901), weekend staffing/skills, Software Install knowledge articles, FCR plan.
5. **Closed loop:** Teams recap captures the actions; Outlook reply answers the CIO's three asks.

## Expected actions from the role-play (Step 6)

| Action | Owner | Due |
|---|---|---|
| Enforce CAB approval for network firmware changes | Ravi Menon | 15 Nov 2026 |
| 5-store pilot ring for firmware updates + pre-staged rollback images | Ravi Menon | 30 Nov 2026 |
| Major-incident status banner on the Fabrikam portal | Sam Lee | 15 Nov 2026 |
| Approve password self-service guide | Laura Chen (Fabrikam comms) | 8 Nov 2026 |
| Launch password self-service | Sam Lee | 15 Nov 2026 |
| Refresh top 10 software install knowledge articles | Sam Lee (Desktop lead) | 22 Nov 2026 |
| Weekend staffing and skills proposal | Anita Rao | 3 Dec 2026 |
| Reflect P1/P2 service credits on October invoice | Anita Rao | October invoice |
| Send meeting summary and actions | Anita Rao | 5 Nov 2026 |

## Timing plan (≈45 min)

| Step | Minutes |
|---|---|
| Intro & scenario | 3 |
| 1 – Briefing (Copilot Chat) | 5 |
| 2 – Analysis (Excel) | 10 |
| 3 – Insights | 5 |
| 4 – Report (Word) | 8 |
| 5 – Deck (PowerPoint) | 5 |
| 6 – Meeting & follow-up (Teams, Outlook) | 9 |

## Tips

- **Pre-record Step 6** (or keep a previous recording) in case live transcription/recap is slow.
- **Pre-generate** a Word report and deck as backups in case Copilot is slow during delivery.
- If Copilot calculates resolution SLA including open tickets, use it as a teaching moment: *"Always check how a metric is defined."*
- Ask learners: *"Which insight would you lead with for this CIO, and why?"*
