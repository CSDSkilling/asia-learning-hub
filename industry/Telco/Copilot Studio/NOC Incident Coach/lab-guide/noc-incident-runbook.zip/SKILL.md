---
name: noc-incident-runbook
description: "Procedures and response formats for the AsterWave NOC Incident Response Runbook (AW6). Use this skill for alarm correlation, severity and bulletin update intervals, runbook diagnosis, action selection and approval requests, restoration verification and status bulletin updates, change freezes, and escalation."
---

# AsterWave NOC Incident Response Runbook

These are the NOC incident response procedures for AsterWave Mobile, a fictional mobile network operator used for training. This skill defines how to locate runbook clauses, retrieve events, follow each stage's procedures and response format, and prepare inputs for write tools. Continue to follow the agent instructions on evidence, citations, and write-tool restrictions whenever using this skill.

## Sources

| Source | Location | How to use |
|---|---|---|
| AW6 Runbook v1.1 | `references/AW6_NOC_Incident_Runbook.md` | Look up clauses by ID (for example, ALM-2.1). Verify figures, tables, approvers, and deadlines against this file every time; do not answer from memory. |
| NOC Events | **Get Incidents Events** tool (NOC Event table) | Alarms, KPIs, diagnostics, field updates, changes, review actions, and log notes by EventID |
| Status Bulletins | **Network Status** knowledge source | Status, Start, LastUpdated, EstimatedOrRestoredAt, Duration, CreditEligible, and CustomerMessage by IncidentID |

The runbook refers to an event export and the AW4 document. Interpret those references as follows for this agent.

| Runbook reference | Interpretation for this agent |
|---|---|
| event export, AW7_NOC_Event_Log, NOC event log | NOC Event rows returned by **Get Incidents Events** |
| AW4, AW4_Network_Status_Snapshot, status bulletin | **Network Status** knowledge source |
| AW4 "As of" time | Current scenario time: Friday, 2026-10-30 10:00 |
| Update AW4 | **Update Status Bulletin** tool, only after the user has reviewed and confirmed the proposed update |
| Approval request (CHG-6) | **Request Action Approval** tool, only after the user has reviewed and confirmed the proposed request |
| Record the evidence in the NOC event log (RBK-0.2) | Do not write event entries directly; suggest what should be recorded. |
| region summary line (BUL-1.3) | This field is not present in Network Status. Include it only as a suggested sentence in the response. |
| AW2 clauses (OUT, SRV, COM) | These are not among this agent's sources. Mention clause IDs only; do not infer their contents. |

## Event Retrieval

- When event data is needed, call **Get Incidents Events** first. StartTime and EndTime use the `yyyy-MM-ddTHH:mm:ss` format.
- The default query window is from 00:00:00 seven days before the incident started through 23:59:59 on the day after the current scenario time. For INC-077, query from `2026-10-23T00:00:00` through `2026-10-31T23:59:59`.
- Events is a JSON array string. Examine all EventCount rows; do not stop at the first match.
- A row whose Type is `Log note` is a recordkeeping note. Do not count it as an alarm or action.
- A row whose Time is later than the current scenario time describes a future or scheduled activity (for example, a change whose Notes say `Scheduled; not started`). Do not treat it as completed.
- If the same time window has already been queried during the current conversation, reuse those results. Query again if the user reports a new event or after a write tool has been invoked.

## General Rules

- Cite the source of each factual statement, for example: (EV-118, NOC Event), (ALM-2.1, AW6 Runbook), (INC-077, Network Status).
- Label measurements and actions supplied by the user as **Reported by user**, and use their reported timestamp as the new current scenario time when it is later.
- Mark a root cause as **Confirmed** only if it meets RBK-0.3; otherwise mark it as **Hypothesis**.
- Show calculations on one line with input values and the relevant clause. Include the day of the week when giving business-day deadlines.
- Answer only the stage relevant to the user's question and suggest the next step in one line at the end, unless a write-tool confirmation question must end the response.
- Respond entirely in English, including summaries, tables, approval drafts, confirmation questions, and bulletin explanations.

## Stage 1: Alarm Correlation

**Procedure**

1. Collect all Alarm rows where ServiceAffecting is `Yes`.
2. Check whether at least three sites using the same UpstreamNode raised alarms within 15 minutes (ALM-2.1).
3. Group alarms from the shared hub and its links (NET-3), along with later alarms from the same sites, hub, or links while the incident remains open, including repeated alarms, into the same incident (ALM-2.2). Treat flapping as one alarm (ALM-2.5).
4. Identify the earliest service-affecting alarm on the shared hub or link as the **probable root alarm** (ALM-2.3).
5. Label alarms whose LinkedIncident is `Not linked` as **Not yet linked** (ALM-1.3).
6. Keep alarms from a different region or UpstreamNode, non-service-affecting alarms, and core platform alarms separate. Explain why, citing the relevant clause (ALM-2.4, ALM-3).
7. Add the subscriber estimates for the affected sites from NET-3 and determine severity using the SEV-1.1 table (SEV-1.2).
8. Calculate the next status bulletin deadline by adding the SEV-2.1 update interval to LastUpdated in Network Status (BUL-1.2).

**Response Format**

- **Correlated Alarms:** Table (EventID | Time | Element | Description | Linked Status)
- **Alarms to Keep Separate:** EventID and reason (with clause)
- **Incident and Severity:** Include a one-line calculation
- **Next Bulletin Deadline**
- **Sources**

## Stage 2: Diagnosis

**Procedure**

1. Select the runbook that matches the pattern: RBK-1 for data issues affecting multiple sites, RBK-2 for a single site, and RBK-3 for SMS delays (RBK-0.1).
2. Match each runbook step against NOC Event rows. Mark steps lacking evidence as **Needs confirmation**.
3. For Step 5 of RBK-1, examine only Change rows for elements on the incident path (NET-3) whose changes started within the 72 hours before the incident start time. Changes in other regions and changes that have not started are not causes.
4. Mark as **Confirmed** only what was directly verified by a measurement or test. Reasons why a link degraded (for example, a temporary fix from an earlier incident) remain **Hypothesis** until confirmed in the field (RBK-0.3). Show the relevant Review action and Field update rows as supporting evidence.

**Response Format**

- **Runbook Checks:** Table (Step | Evidence | Result)
- **Confirmed**
- **Hypothesis**
- **Next Step**
- **Sources**

## Stage 3: Action Selection and Approval Request

**Procedure**

1. Review all 10 actions in CHG-3. An action is ineligible if its Status is not `Active`. It is eligible only if its Use when condition matches the evidence and every required condition is satisfied (CHG-3.2).
2. Calculate the conditions. Example: Post-switch load = (Protected link load + Traffic to be transferred) ÷ Capacity; the threshold is 70% or less (CHG-4.2). Mark conditions that cannot be verified from events as **Needs confirmation**.
3. Select actions according to CHG-4.1. To restore service now, choose the lowest-risk eligible restoration action. To address the underlying cause, also select an appropriate repair action. Clearly label actions that are already in progress.
4. Identify the change type (CHG-1) and approver (CHG-2.1). During a Sev-1 or Sev-2 incident, a non-Standard action is an Emergency change and must be reviewed by the CAB within two business days (CHG-1.2).
5. If a Normal change is scheduled for an element on the incident path, describe the CHG-5 change freeze and direct the user to the Change Manager escalation path (NES-7).
6. For Medium- or High-risk actions, prepare a CHG-6 approval request draft.

**Approval Request Draft (CHG-6)**

- Write the full draft in English, since approval emails and NOC Event records are in English. Provide any on-screen summary in English as well.
- Include: Incident ID and severity; ActionID and description; risk level and change type; approver; verified conditions and EventIDs; rollback; success criteria (VER-1.1); and the final line `Approval: Pending`.

**Request Action Approval Tool**

- Present the complete CHG-6 draft, ask **"Would you like me to send this approval request as shown?"**, and end the response. Do not invoke **Request Action Approval** in that response.
- Invoke **Request Action Approval** only after the user has reviewed the draft and explicitly confirms it in a subsequent message. An initial request to "send" does not count as confirmation.
- If the user requests changes, show the complete revised draft and request confirmation again in a subsequent message. If the user cancels, do not invoke the tool; acknowledge the cancellation.
- Do not use this tool for Low-risk actions (CHG-2.1).
- **Inputs:**
  - IncidentID: Incident identifier (for example, INC-077)
  - ActionID: Action identifier (for example, ACT-01)
  - ApproverRole: Approver role name exactly as written in CHG-3 (for example, NOC Shift Manager)
  - Region: Region name exactly as written in English (for example, Meranti Coast)
  - RequestTime: Current scenario time in `yyyy-MM-ddTHH:mm:ss` format (for example, `2026-10-30T10:00:00`)
  - ApprovalRequest: The complete CHG-6 draft shown to and confirmed by the user
- After invocation, report the returned EventID and Result. The approval remains **Pending**; do not present it as approved (CHG-2.2).

**Response Format**

- **Eligible Actions:** Table (ActionID | Description | Reason for Eligibility | Risk Level | Approver | Rollback)
- **Ineligible Actions:** ActionID and applicable rule
- **Recommendation**
- **Approval Request Draft:** Complete CHG-6 text, ending with `Approval: Pending`
- **Sources**
- If presenting a draft for approval, end the response by asking **"Would you like me to send this approval request as shown?"** Do not invoke the tool in that response.

## Stage 4: Restoration Verification and Bulletin Update

**Procedure**

1. Check all three VER-1.1 criteria individually: (a) KPIs at affected sites meet the NET-4 thresholds continuously for 30 minutes; (b) no new service-affecting alarms occur at the affected sites, hub, or links for 30 minutes; (c) the action that restored service is recorded with its time and approver.
2. Classify the result as **Restored** when all criteria are met; **Not yet** when any criterion is not met; and **Needs confirmation** when supporting evidence is unavailable (VER-1.2).
3. The restoration time is the start of the 30-minute stable period (VER-1.3). Calculate Duration from the incident start time (IST-1.2) to the restoration time (IST-1.3).
4. Determine CreditEligible according to IST-3.
5. A bulletin update is required when Status, ETR, or CreditEligible changes (within 15 minutes), or when the scheduled update is due under SEV-2.1 (BUL-1.2). Include the bulletin update section in the Stage 4 response only when an update is required.
6. Compose CustomerMessage in English using the BUL-2.3 pattern and following BUL-2.2. Do not include root causes, equipment or link names, vendors, contractors, or blame.
7. Summarize follow-up actions: closure criteria (VER-2); repeat incidents (VER-3: check Network Status rows and Review action rows for another incident involving the same link, hub, or router within the previous 30 days); post-incident review deadline (VER-4.1, including weekday); and notification recipients (BUL-3).

**Bulletin Row Draft**

- Present the current values of unchanged fields alongside the updated values. For scheduled updates, recalculate only LastUpdated and Duration.
- Match the formats used in the existing Network Status row:
  - Status: One of `Investigating`, `Restoring`, `Restored`, `Scheduled`
  - LastUpdated: Scenario time when the update is made, for example, `30 Oct 2026 09:40`
  - EstimatedOrRestoredAt: For example, `Estimated restore 30 Oct 2026 12:00`, `Restored 21 Oct 2026 18:25`, `Not yet available`
  - Duration: For an ongoing incident, for example, `2 h 15 min so far`; after restoration, for example, `5 h 15 min`
  - CreditEligible: One of `Yes`, `No`, `Pending`

**Update Status Bulletin Tool**

- Present the complete proposed Network Status row and CustomerMessage, ask **"Would you like me to publish this bulletin update as shown?"**, and end the response. Do not invoke **Update Status Bulletin** in that response.
- Invoke **Update Status Bulletin** only after the user has reviewed the proposed update and explicitly confirms it in a subsequent message. An initial request to "publish" does not count as confirmation.
- If the user requests changes, show the complete revised row and CustomerMessage and ask for confirmation again. If the user cancels, do not invoke the tool; acknowledge the cancellation.
- **Inputs:** IncidentID, Status, LastUpdated, EstimatedOrRestoredAt, Duration, CreditEligible, CustomerMessage (in the formats specified above)
- Do not update Status to `Restored` unless all VER-1.1 criteria are satisfied.
- Before changing CreditEligible, require the user to confirm that the NOC Shift Manager approved the decision (IST-3.4).
- After invocation, report Result and the updated Status.

**Response Format**

- **Restoration Verification:** Table (Criterion | Evidence | Met?)
- **Decision:** One of `Restored`, `Not yet`, `Needs confirmation`
- **Bulletin Update:** Draft Network Status row and CustomerMessage (only when an update is required)
- **Follow-up Actions:** Closure, repeat incidents, review deadline, recipients to notify
- **Sources**
- If presenting a bulletin draft, end the response by asking **"Would you like me to publish this bulletin update as shown?"** Do not invoke the tool in that response.
