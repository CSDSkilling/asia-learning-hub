---
name: noc-incident-runbook
description: "Procedures and response formats for the AsterWave NOC Incident Response Runbook (AW6). Use this skill for alarm correlation, severity and bulletin update intervals, runbook-based diagnosis, action selection and approval requests, restoration verification and status bulletin updates, change freezes, and escalations."
---

# AsterWave NOC Incident Response Runbook

This skill defines the NOC incident response procedures for AsterWave Mobile, a fictional mobile network operator used for training. It specifies how to locate runbook sections, retrieve events, follow each stage, format responses, and prepare inputs for write tools. Continue to follow the agent instructions regarding evidence, citations, and write-tool restrictions when using this skill.

## Sources

| Source | Location | How to use it |
|---|---|---|
| AW6 Runbook v1.1 | `references/AW6_NOC_Incident_Runbook.md` | Look up information by section ID (for example, ALM-2.1). Verify numerical thresholds, tables, approvers, and deadlines against this file every time; do not answer from memory. |
| NOC events | **Get Incidents Events** tool (NOC Event table) | Alarms, KPIs, diagnostics, field updates, changes, review actions, and log notes identified by EventID. |
| Status bulletins | **Network Status** knowledge source | Status, Start, LastUpdated, EstimatedOrRestoredAt, Duration, CreditEligible, and CustomerMessage identified by IncidentID. |

The runbook refers to an event export file and the AW4 document. Interpret these references as follows when using this agent.

| Runbook reference | Interpretation for this agent |
|---|---|
| event export, AW7_NOC_Event_Log, NOC event log | NOC Event rows returned by **Get Incidents Events**. |
| AW4, AW4_Network_Status_Snapshot, status bulletin | **Network Status** knowledge source. |
| AW4 "As of" time | Current scenario time: Friday, 2026-10-30 10:00. |
| Update AW4 | **Update Status Bulletin** tool, only when explicitly requested by the user. |
| Approval request (CHG-6) | **Request Action Approval** tool, only when explicitly requested by the user. |
| Record the evidence in the NOC event log (RBK-0.2) | Do not write event records directly; recommend what should be recorded. |
| region summary line (BUL-1.3) | This field is not in Network Status. Include it only as a suggested statement in the response. |
| AW2 sections (OUT, SRV, COM) | These are not among this agent's sources. Mention section IDs only; do not infer their content. |

## Event Retrieval

- When event data is needed, call **Get Incidents Events** first. Provide StartTime and EndTime in `yyyy-MM-ddTHH:mm:ss` format.
- The default window starts at 00:00:00 seven days before the incident began and ends at 23:59:59 on the day after the current scenario time. For INC-077, use `2026-10-23T00:00:00` through `2026-10-31T23:59:59`.
- Events is a JSON array encoded as a string. Examine every row indicated by EventCount; do not stop at the first match.
- Rows with Type set to `Log note` are log entries. Do not count them as alarms or actions.
- Rows with a Time later than the current scenario time represent future scheduled activities (for example, a change with Notes set to `Scheduled; not started`). Do not treat them as completed events.
- If the same time window was already retrieved during the current conversation, reuse those results. Retrieve events again if the user reports new events or after a write tool has been invoked.

## General Rules

- Cite a source for every factual statement. Examples: (EV-118, NOC Event), (ALM-2.1, AW6 Runbook), (INC-077, Network Status).
- Label measurements and actions supplied by the user as **Reported by user**, and use their timestamp as the new current scenario time.
- Label a root cause as **Confirmed** only when RBK-0.3 is satisfied; otherwise, label it as **Hypothesis**.
- Show each calculation on one line, including its inputs and the applicable runbook section. Include the day of the week for deadlines expressed in business days.
- Answer only the stage relevant to the user's question, and suggest the next step in one line at the end.

## Stage 1: Alarm Correlation

### Procedure

1. Collect all Alarm rows where ServiceAffecting is `Yes`.
2. Check whether alarms were raised within 15 minutes at three or more sites sharing the same UpstreamNode (ALM-2.1).
3. Correlate alarms from the shared hub and its links (NET-3), together with subsequent alarms—including repeated alarms—from the same sites, hub, or links while the incident remains open (ALM-2.2). Treat flapping as one alarm (ALM-2.5).
4. Identify the earliest service-affecting alarm from the shared hub or link as the **probable root alarm** (ALM-2.3).
5. Label alarms whose LinkedIncident is `Not linked` as **Not yet linked** (ALM-1.3).
6. Keep alarms from another region or UpstreamNode, non-service-affecting alarms, and core platform alarms separate. Explain why, citing the applicable sections (ALM-2.4, ALM-3).
7. Add the NET-3 estimated subscriber counts for affected sites and determine severity using the SEV-1.1 table (SEV-1.2).
8. Calculate the next bulletin deadline by adding the SEV-2.1 interval to LastUpdated in Network Status (BUL-1.2).

### Response Format

- **Correlated alarms:** Table (EventID | Time | Element | Description | Link status).
- **Alarms to keep separate:** EventID and reason (including runbook section).
- **Incident and severity:** Include a one-line calculation.
- **Next bulletin deadline.**
- **Sources.**

## Stage 2: Diagnosis

### Procedure

1. Select the runbook that matches the incident pattern: RBK-1 for multi-site data issues, RBK-2 for a single-site issue, and RBK-3 for SMS delays (RBK-0.1).
2. Compare each runbook step against NOC Event rows. Mark steps without supporting evidence as **Needs confirmation**.
3. For Step 5 of RBK-1, consider only Change rows for elements on the affected path (NET-3) where the change began within 72 hours before the incident start time. Changes in other regions and changes that have not yet started are not causes.
4. Mark a finding as **Confirmed** only when directly established through measurements or tests. Treat explanations for why a link deteriorated (for example, a temporary fix from a previous incident) as **Hypothesis** until confirmed in the field (RBK-0.3). Include relevant Review action and Field update rows.

### Response Format

- **Runbook checks:** Table (Step | Evidence | Result).
- **Confirmed.**
- **Hypothesis.**
- **Next step.**
- **Sources.**

## Stage 3: Action Selection and Approval Request

### Procedure

1. Review all 10 actions in CHG-3. An action is ineligible if its Status is not `Active`. It is eligible only when its Use when criteria match the evidence and all conditions are satisfied (CHG-3.2).
2. Calculate the required conditions. For example: Post-switch load = (Protected link load + Traffic to be transferred) ÷ Capacity; the threshold is 70% or less (CHG-4.2). Mark conditions that cannot be verified from events as **Needs confirmation**.
3. Apply CHG-4.1. For immediate service restoration, choose the eligible restoration action with the lowest risk. For a permanent root-cause fix, also select a repair action. Indicate when an action is already in progress.
4. State the change type (CHG-1) and required approver (CHG-2.1). During a Sev-1 or Sev-2 incident, a non-Standard action is an Emergency change that must be reviewed by CAB within two business days (CHG-1.2).
5. If a Normal change is scheduled for an element on the affected path, explain the CHG-5 change freeze and direct the user to the Change Manager escalation path (NES-7).
6. For Medium- or High-risk actions, prepare an approval request draft using the CHG-6 format.

### Approval Request Draft (CHG-6)

- Write the full request and the on-screen summary in English. Approval emails and NOC Event records are in English.
- Include: Incident ID and severity; ActionID and description; risk level and change type; approver; verified conditions and EventIDs; rollback plan; success criteria (VER-1.1); and the final line `Approval: Pending`.

### Request Action Approval Tool

- Invoke **Request Action Approval** only after the user has reviewed the draft and explicitly requests that it be sent. Do not use this tool for Low-risk actions (CHG-2.1).
- **Inputs:**
  - **IncidentID:** Incident ID (for example, `INC-077`).
  - **ActionID:** Action ID (for example, `ACT-01`).
  - **ApproverRole:** Exact English name of the approver role from CHG-3 (for example, `NOC Shift Manager`).
  - **Region:** Exact English region name (for example, `Meranti Coast`).
  - **RequestTime:** Current scenario time in `yyyy-MM-ddTHH:mm:ss` format (for example, `2026-10-30T10:00:00`).
  - **ApprovalRequest:** Full CHG-6 draft shown to the user.
- After calling the tool, report the returned EventID and Result. Approval remains **Pending**; do not imply that the action has been approved (CHG-2.2).

### Response Format

- **Eligible actions:** Table (ActionID | Description | Eligibility rationale | Risk | Approver | Rollback).
- **Ineligible actions:** ActionID and applicable rule.
- **Recommendation.**
- **Approval request draft:** Full CHG-6 text, ending with `Approval: Pending`.
- **Sources.**

## Stage 4: Restoration Verification and Bulletin Update

### Procedure

1. Check each of the three VER-1.1 criteria: (a) affected-site KPIs meet NET-4 thresholds continuously for 30 minutes; (b) no new service-affecting alarms occur at the affected sites, hub, or links during those 30 minutes; and (c) the action that restored service is recorded with its timestamp and approver.
2. Return **Restored** only if all criteria are satisfied; **Not yet** if any criterion is not satisfied; or **Needs confirmation** if supporting evidence is missing (VER-1.2).
3. The restoration time is the start of the 30-minute stable period (VER-1.3). Calculate Duration from the incident start time (IST-1.2) to the restoration time (IST-1.3).
4. Determine CreditEligible using IST-3.
5. A bulletin update is required when Status, ETR, or CreditEligible changes (within 15 minutes), or when the scheduled update deadline defined in SEV-2.1 is reached (BUL-1.2). Include a bulletin update section in the Stage 4 response only when an update is required.
6. Write CustomerMessage in English using the BUL-2.3 pattern and comply with BUL-2.2. Do not mention causes, equipment or link names, vendors, contractors, or responsibility/blame.
7. Summarize follow-up actions: closure criteria (VER-2); recurring incidents (VER-3: check Network Status rows and Review action rows for another incident involving the same link, hub, or router within the past 30 days); post-incident review deadline (VER-4.1, including the day of the week); and notification recipients (BUL-3).

### Bulletin Row Draft

- Display all current values, including fields that are not changing. For scheduled updates, recalculate only LastUpdated and Duration.
- Match the formats used by the existing Network Status row:
  - **Status:** One of `Investigating`, `Restoring`, `Restored`, or `Scheduled`.
  - **LastUpdated:** Current scenario time when the bulletin is updated, for example, `30 Oct 2026 09:40`.
  - **EstimatedOrRestoredAt:** For example, `Estimated restore 30 Oct 2026 12:00`, `Restored 21 Oct 2026 18:25`, or `Not yet available`.
  - **Duration:** For example, `2 h 15 min so far` for an ongoing incident or `5 h 15 min` after restoration.
  - **CreditEligible:** One of `Yes`, `No`, or `Pending`.

### Update Status Bulletin Tool

- Invoke **Update Status Bulletin** only after the user has reviewed the row draft and CustomerMessage and explicitly requests that the bulletin be published.
- **Inputs:** IncidentID, Status, LastUpdated, EstimatedOrRestoredAt, Duration, CreditEligible, CustomerMessage (preserving the formats above).
- Do not update Status to `Restored` unless all VER-1.1 criteria have been satisfied.
- Before updating CreditEligible, require the user to confirm that the NOC Shift Manager has approved the decision (IST-3.4).
- After calling the tool, report Result and the updated Status.

### Response Format

- **Restoration verification:** Table (Criterion | Evidence | Satisfied?).
- **Decision:** One of `Restored`, `Not yet`, or `Needs confirmation`.
- **Bulletin update:** Network Status row draft and CustomerMessage (only when an update is required).
- **Follow-up actions:** Closure, recurring incidents, review deadline, and notification recipients.
- **Sources.**
