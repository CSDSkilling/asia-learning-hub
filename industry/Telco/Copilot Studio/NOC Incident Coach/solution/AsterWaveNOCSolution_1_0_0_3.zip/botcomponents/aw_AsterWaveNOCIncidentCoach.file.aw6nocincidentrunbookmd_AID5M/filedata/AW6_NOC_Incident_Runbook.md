# AW6 — AsterWave Mobile: NOC Incident Runbook

Rules, runbooks and approvals for network incidents · Version 1.1 · Fictional – for training use only

| Field | Value |
|---|---|
| Document | AW6_NOC_Incident_Runbook |
| Clause prefixes | NET (network reference), ALM (alarms and grouping), SEV (severity and update cadence), IST (incident status and credit eligibility), RBK (runbooks), CHG (actions, approvals and changes), VER (restoration and closure), BUL (status bulletin and communication), NES (NOC escalation matrix) |
| Version | 1.1 |
| Effective date | 1 October 2026 |
| Owner | Network Operations Centre (NOC) |
| Status | FICTIONAL – FOR TRAINING USE ONLY |

AsterWave Mobile is a fictional mobile operator in the fictional Meranti Isles. All network elements, rules, numbers and names in this runbook are invented for Microsoft training demos. This runbook sets the rules that NOC engineers and NOC shift managers follow during network incidents.

Live events, such as alarms, KPI checks, diagnostics, field updates, changes and review actions, are in the NOC event log in the monitoring system. For an incident, the NOC exports the events in the layout of AW7_NOC_Event_Log and attaches the export in the chat with the agent. The status bulletin that Customer Care reads is AW4_Network_Status_Snapshot, and the NOC owns it (BUL-1). Treat the AW4 "As of" time as the current time. The Log note row of an export gives its export time.

## Roles used in this runbook

| Role | What the role does |
|---|---|
| NOC Engineer | Watches alarms 24/7, raises incidents, runs runbook checks and takes Low-risk actions |
| NOC Shift Manager | Leads the shift, owns Sev-2 incidents, and approves Medium-risk actions and CreditEligible decisions |
| Head of Network Operations | Approves High-risk actions and leads Sev-1 incidents as Incident Commander |
| Change Manager | Runs the change advisory board (CAB), reschedules changes and reviews Emergency changes |
| Field Operations | Sends field teams to repair sites, fibre and power |
| Transport Engineering (on call) | Third-line support for links and routers |
| Core Engineering (on call) | Third-line support for core platforms, such as the SMS centre |
| Problem Manager | Owns problem records for repeat incidents and temporary fixes |
| Care Operations Lead | Receives NOC updates and briefs Customer Care |

## NET — Network reference

### NET-1 Regions and core

NET-1.1 The network covers three regions: Meranti Coast, Seahaven Metro and Coral East.

NET-1.2 Core site CORE-SH-1 in Seahaven Metro carries mobile data, voice and SMS for all three regions. When only one region shows a symptom and CORE-SH-1 has no alarms, the core is unlikely to be the cause (RBK-1, step 2).

NET-1.3 SMS centre SMSC-SH-1 at CORE-SH-1 handles SMS for all Seahaven Metro subscribers (about 182,000).

### NET-2 Meranti Coast transport

NET-2.1 Fibre ring MC-RING-1 connects hub site MC-HUB-07 to two aggregation routers: AGG-MC-02 over link LNK-207 (the primary path) and AGG-MC-01 over link LNK-107 (the protection path). Both routers connect to CORE-SH-1.

NET-2.2 LNK-207 and LNK-107 each have a capacity of 10 Gbps.

NET-2.3 Automatic protection switching moves traffic to LNK-107 only when LNK-207 goes fully down. A degraded link (low optical power, interface errors or flapping) doesn't trigger it, so a manual switch is needed (ACT-01).

NET-2.4 Sites MC-109 and MC-110 connect directly to AGG-MC-01. They don't use MC-HUB-07, LNK-207 or LNK-107.

### NET-3 Element table

NET-3.1 UpstreamNode is the hub or router that an element reports through. Alarms on a link are reported by the hub at its near end, so their UpstreamNode is that hub.

| Element | Type | Region | UpstreamNode | Path to the core | Estimated subscribers |
|---|---|---|---|---|---|
| MC-101 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 5,200 |
| MC-102 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 4,800 |
| MC-103 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 6,100 |
| MC-104 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 3,900 |
| MC-105 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 5,700 |
| MC-106 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 4,400 |
| MC-107 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 6,300 |
| MC-108 | Cell site (4G and 5G) | Meranti Coast | MC-HUB-07 | MC-HUB-07 > LNK-207 > AGG-MC-02 > CORE-SH-1 | 5,200 |
| MC-109 | Cell site (4G and 5G) | Meranti Coast | AGG-MC-01 | AGG-MC-01 > CORE-SH-1 | 4,600 |
| MC-110 | Cell site (4G and 5G) | Meranti Coast | AGG-MC-01 | AGG-MC-01 > CORE-SH-1 | 5,100 |
| MC-HUB-07 | Hub site | Meranti Coast | MC-HUB-07 | LNK-207 > AGG-MC-02 (protection: LNK-107 > AGG-MC-01) | Carries MC-101 to MC-108 |
| LNK-207 | Fibre link, primary | Meranti Coast | MC-HUB-07 | MC-HUB-07 to AGG-MC-02 | Carries MC-101 to MC-108 |
| LNK-107 | Fibre link, protection | Meranti Coast | MC-HUB-07 | MC-HUB-07 to AGG-MC-01 | Standby for LNK-207 |
| AGG-MC-01 | Aggregation router | Meranti Coast | CORE-SH-1 | AGG-MC-01 > CORE-SH-1 | Not applicable |
| AGG-MC-02 | Aggregation router | Meranti Coast | CORE-SH-1 | AGG-MC-02 > CORE-SH-1 | Not applicable |
| CE-301 | Cell site (4G and 5G) | Coral East | AGG-CE-01 | AGG-CE-01 > CORE-SH-1 | 3,700 |
| AGG-CE-01 | Aggregation router | Coral East | CORE-SH-1 | AGG-CE-01 > CORE-SH-1 | Not applicable |
| SMSC-SH-1 | SMS centre | Seahaven Metro | CORE-SH-1 | At CORE-SH-1 | About 182,000 (all Seahaven Metro subscribers) |
| CORE-SH-1 | Core site | Seahaven Metro | Not applicable | Not applicable | All regions |

### NET-4 KPI thresholds

| KPI | Normal | Used in |
|---|---|---|
| Data packet loss (15-minute average per site) | 1.0% or less | ALM, VER |
| Data latency, site to core (15-minute average) | 40 ms or less | ALM, VER |
| Data session success rate | 99.0% or more | ALM, VER |
| Share of SMS delivered later than 10 minutes | 2% or less | RBK-3, IST-3 |
| SMS centre message queue | 5,000 messages or fewer | RBK-3 |
| Call setup success rate | 99.5% or more | VER |
| Optical receive power on a fibre link | -8 to -18 dBm (below -22 dBm raises a signal-degrade alarm) | RBK-1 |
| Interface errors (CRC) on a link | 0 per 15 minutes | RBK-1 |
| Protection link load after a switch | 70% of capacity or less | CHG-3 (ACT-01, ACT-02) |

## ALM — Alarms and grouping

### ALM-1 Reading the event log

ALM-1.1 An event export lists events up to its export time, which its Log note row gives, one row per EventID, and changes scheduled after it. The Type column shows Alarm, KPI, Diagnostic, Field update, Change, Review action or Log note.

ALM-1.2 ServiceAffecting = Yes means the alarm can affect customer service. Facilities alarms, such as an open cabinet door or a high cabinet temperature, are No.

ALM-1.3 LinkedIncident shows the alarms already linked to an incident. Alarms that arrive later are often not linked yet; link them with ALM-2.

### ALM-2 Grouping alarms into one incident

ALM-2.1 Group service-affecting alarms into one incident when 3 or more sites with the same UpstreamNode raise them within 15 minutes of each other.

ALM-2.2 Also link to that incident the alarms on the shared UpstreamNode itself and on its links (NET-3), and later alarms from the same sites, hub or links while the incident is open.

ALM-2.3 The probable root alarm is the earliest service-affecting alarm on the shared hub or its links. Alarms from the sites are symptoms.

ALM-2.4 Don't group alarms from another region, from elements with a different UpstreamNode, or alarms that aren't service-affecting.

ALM-2.5 Flapping means a link goes down and up 3 or more times in 30 minutes. Treat the flaps as one alarm. Flapping points to a physical fault, such as damaged fibre or a poor splice (RBK-1, step 4).

ALM-2.6 Worked example: at 13:58 a hub's uplink raises a signal-degrade alarm, and at 14:02, 14:06 and 14:11 three sites behind that hub raise packet-loss alarms. Group all four alarms into one incident; the uplink alarm at 13:58 is the probable root alarm (ALM-2.3). A temperature alarm at 14:05 from a site behind another router stays separate (ALM-2.4).

### ALM-3 Alarms that aren't grouped

ALM-3.1 A service-affecting alarm on a core platform, such as an SMS centre, is its own incident. For SMS, use RBK-3.

ALM-3.2 An alarm that isn't service-affecting needs no incident (Sev-4, SEV-1.1). Raise a facilities ticket for Field Operations to handle within 1 business day. If the alarm clears by itself, note it on the ticket.

ALM-3.3 For service-affecting alarms from a single site with no shared pattern, use RBK-2.

## SEV — Severity and update cadence

### SEV-1 Severity

SEV-1.1 Set the severity with this table.

| Severity | When it applies | Owner |
|---|---|---|
| Sev-1 Critical | A service is unavailable for 50,000 or more estimated subscribers, or emergency calls are affected | Head of Network Operations (Incident Commander) |
| Sev-2 Major | A service is unavailable for fewer than 50,000 estimated subscribers, or degraded (slow, intermittent or delayed) for 20,000 or more | NOC Shift Manager |
| Sev-3 Minor | A service is degraded for fewer than 20,000 estimated subscribers | NOC Engineer |
| Sev-4 None | No customer impact, for example a facilities alarm. No incident is raised (ALM-3.2) | NOC Engineer |

SEV-1.2 The number of estimated subscribers affected is the sum of the NET-3 estimates for the affected sites. For a platform that serves a whole region, such as an SMS centre, use its NET-3 figure.

SEV-1.3 Worked example: three degraded sites with 5,000, 4,000 and 3,500 estimated subscribers give 5,000 + 4,000 + 3,500 = 12,500. That is under 20,000, so the incident is Sev-3.

### SEV-2 Update cadence

SEV-2.1 Update the status bulletin (BUL-1) at least every 30 minutes for Sev-1, every 60 minutes for Sev-2 and every 4 hours for Sev-3. Count from the Last updated time in AW4.

SEV-2.2 Worked example: a Sev-2 incident last updated at 13:20 needs its next update by 14:20.

## IST — Incident status and credit eligibility

### IST-1 Status, start time and duration

IST-1.1 Status values are Investigating (the cause is being identified), Restoring (a fix is in progress, such as a field repair or an action), Restored (service is back to normal under VER-1) and Scheduled (planned maintenance). Customer Care uses the same values (OUT-2.1 in AW2).

IST-1.2 The start time is when customer impact begins: the first service-affecting alarm or KPI breach from an affected site or, for a platform such as an SMS centre, the first service-affecting alarm from that platform. Earlier alarms on a link or hub point to the probable root cause (ALM-2.3) but don't set the start time.

IST-1.3 The duration runs from the start time to the restore time (VER-1.3). For an open incident, it runs to the AW4 "As of" time.

### IST-2 Estimated restore time

IST-2.1 Give an estimated restore time (ETR) only from an engineering plan, such as a field team's arrival time plus the repair time. Always call it an estimate. Without a plan, write "Not yet available".

IST-2.2 Worked example: a field team arrives at 14:10 and needs 50 minutes, so the ETR is 15:00.

### IST-3 Credit eligibility

IST-3.1 Set CreditEligible = Yes when the incident is unplanned and a KPI in the event export shows customer impact beyond the NET-4 threshold for the affected service.

IST-3.2 Set CreditEligible = No for planned maintenance (IDs that start with MNT-) or when there is no customer impact.

IST-3.3 Keep CreditEligible = Pending until the KPI evidence is in, and decide within 60 minutes of the start time.

IST-3.4 The NOC Shift Manager approves every CreditEligible decision, and the NOC updates AW4 within 15 minutes (BUL-1.2). Customer Care gives service credits only when CreditEligible = Yes (SRV-1.2 in AW2).

IST-3.5 Worked example: an SMS incident starts at 14:05. At 14:40, 9% of SMS are delivered later than 10 minutes (normal: 2% or less), so recommend Yes. The decision is due by 15:05.

## RBK — Runbooks

### RBK-0 Using the runbooks

RBK-0.1 Run the runbook that matches the pattern: RBK-1 for mobile data problems at several sites, RBK-2 for a single site and RBK-3 for SMS delivery.

RBK-0.2 Record the evidence for each step in the NOC event log, with its EventID.

RBK-0.3 Call a cause "confirmed" only when a measurement or test shows it directly, such as low optical power measured on a link. Anything else, including why a link degraded, stays a hypothesis until a field team or an engineer confirms it.

### RBK-1 Mobile data degraded at several sites

| Step | What to check | What it tells you |
|---|---|---|
| 1 | Group the alarms (ALM-2), record the start time (IST-1.2) and set the severity (SEV-1) | The scope of the incident |
| 2 | Whether other regions show the same symptom, and whether CORE-SH-1 has alarms | Other regions normal and no core alarms: the core is unlikely to be the cause |
| 3 | Affected and unaffected sites in the same region (NET-3) | The fault is on the part of the path that only the affected sites share |
| 4 | Optical receive power, interface errors and flapping on the shared link (NET-4, ALM-2.5) | Power below -22 dBm or rising errors: the link is degraded (confirmed). Flapping points to damaged fibre or a poor splice (a hypothesis until inspected) |
| 5 | Changes on the shared path that started in the 72 hours before the start time | A change on another path doesn't explain the fault. A change on the path: consider ACT-06 |
| 6 | The protection path: active alarms, current load and capacity | Whether ACT-01 or ACT-02 is possible (CHG-3) |
| 7 | Restore and repair: choose actions with CHG-4, then verify with VER-1 | The way back to normal service |

### RBK-2 One site degraded or down

| Step | What to check | What it tells you |
|---|---|---|
| 1 | Power alarms (mains and battery) | A power fault needs a field team (ACT-03) |
| 2 | Radio alarms on the site | A radio fault: restart the cell (ACT-08) |
| 3 | Whether the fault continues after ACT-08 | Send a field team (ACT-03) or escalate to the vendor (ACT-07) |

### RBK-3 SMS delivery delay

RBK-3.1 Check the SMS KPIs in the event export: the share of SMS delivered later than 10 minutes and the SMS centre message queue (NET-4).

RBK-3.2 Known error PRB-014: on SMSC-SH-1, a queue worker can stop processing after the nightly batch, so the queue builds up. If the alarm says a queue worker isn't processing, apply the workaround ACT-05.

RBK-3.3 After ACT-05, the queue should fall below 5,000 messages within 20 minutes. If it doesn't, escalate to Core Engineering (NES-6).

RBK-3.4 Decide CreditEligible within 60 minutes of the start time (IST-3).

## CHG — Actions, approvals and changes

### CHG-1 Change types

CHG-1.1 Standard: a Low-risk action marked Standard in CHG-3. No approval is needed; log it.

CHG-1.2 Emergency: any action that isn't Standard, taken to restore service during an open Sev-1 or Sev-2 incident. The CAB reviews every Emergency change within 2 business days after it is done.

CHG-1.3 Normal: planned work. It needs CAB approval and a scheduled window.

### CHG-2 Approval by risk

CHG-2.1 Low risk: a NOC Engineer can act and logs it. Medium risk: the NOC Shift Manager approves. High risk: the Head of Network Operations approves and the Change Manager is informed.

CHG-2.2 Never present an action as approved before the approver confirms it. Never split an action or relabel its risk to avoid an approval.

### CHG-3 Action catalogue

CHG-3.1 Use only the actions in this table.

| ActionID | Action | Use when | Preconditions | Risk | Approver | Rollback | Status |
|---|---|---|---|---|---|---|---|
| ACT-01 | Manual protection switch: move traffic from a degraded ring link to its protection link | A ring link is degraded (low optical power, errors or flapping) but not down, so automatic switching hasn't happened (NET-2.3) | The protection link has no active alarms, and its load after the switch is 70% of capacity or less | Medium | NOC Shift Manager | Switch traffic back to the original link | Active |
| ACT-02 | Force automatic switching by shutting down the degraded link. Traffic drops briefly, and no fallback remains if the protection link fails. | A ring link is degraded but not down | Same as ACT-01 | High | Head of Network Operations | Bring the link back up | Active |
| ACT-03 | Send a field team to inspect and repair a site, fibre or splice | A physical fault is suspected on a link or site (low optical power, flapping or a power fault) | A field team is available | Low | NOC Engineer | Not applicable | Active |
| ACT-04 | Remote reset of an aggregation router line card. Suspended because a reset on 12 Oct 2026 caused a wider outage. | A line card on an aggregation router has failed | None | High | Head of Network Operations | Not applicable | Suspended |
| ACT-05 | Restart the SMS centre queue worker (Standard; workaround for PRB-014) | The SMS queue is above threshold and a queue worker isn't processing (RBK-3.2) | The alarm matches PRB-014 | Low | NOC Engineer | Restart again, then escalate under RBK-3.3 | Active |
| ACT-06 | Roll back a recent change | A change on the incident's path started in the 72 hours before the start time | The change record has a rollback plan | Medium | NOC Shift Manager, with the Change Manager | Re-apply the change | Active |
| ACT-07 | Escalate to vendor technical support | Equipment alarms point to a hardware or software fault on vendor equipment | None | Low | NOC Engineer | Not applicable | Active |
| ACT-08 | Restart one cell (lock and unlock) | One site has a radio fault (RBK-2) | Only one site is affected | Low | NOC Engineer | Unlock the cell | Active |
| ACT-09 | Rebalance traffic with the automated optimisation script. Awaiting CAB approval, so not available yet. | Several links are congested | None | Medium | NOC Shift Manager | Stop the script | Pending |
| ACT-10 | Temporarily limit video streaming quality at the affected sites | A link is congested (load above 80%) and no protection path is available | The Care Operations Lead is informed | Medium | NOC Shift Manager | Remove the limit | Active |

CHG-3.2 An action is eligible only when its Status is Active, its "Use when" matches the evidence and every precondition is met. If a precondition can't be confirmed from the event export, mark the action "Needs confirmation".

### CHG-4 Choosing actions

CHG-4.1 Restore actions bring service back quickly: ACT-01, ACT-02, ACT-04, ACT-05, ACT-06, ACT-08, ACT-09 and ACT-10. Repair actions fix the cause: ACT-03 and ACT-07. To restore service now, choose the eligible restore action with the lowest risk whose "Use when" matches the confirmed fault. To repair the cause, add the eligible repair action. Both can run at the same time.

CHG-4.2 Worked example: a protection link carries 3.0 Gbps, 3.5 Gbps would move to it, and its capacity is 10 Gbps. The load after the switch is (3.0 + 3.5) ÷ 10 = 65%, which is within 70%.

### CHG-5 Change freeze

CHG-5.1 While a Sev-1 or Sev-2 incident is open, and for 24 hours after it closes, no Normal change may start on any element on the incident's path: the affected sites, their hub and links, and the aggregation routers they use (NET-3). Emergency changes for the incident are allowed.

CHG-5.2 The Change Manager reschedules a frozen change through the CAB (NES-7).

### CHG-6 Approval request

CHG-6.1 An approval request includes the incident ID and severity; the ActionID and what it does; the risk and change type; the approver; the preconditions checked, with EventIDs; the rollback; the success criteria (VER-1.1); and the line "Approval: Pending".

## VER — Restoration and closure

### VER-1 Restored

VER-1.1 An incident is Restored only when all three criteria are true: (a) every affected site meets the NET-4 thresholds for the affected service for 30 consecutive minutes; (b) no new service-affecting alarm has come from the affected sites, their hub or links for 30 consecutive minutes; and (c) the action that restored service is logged with its time and approver.

VER-1.2 If a criterion isn't met, the verdict is "Not yet". If the evidence for a criterion is missing, the verdict is "Needs confirmation". Readings that an engineer reports count as evidence; log them in the NOC event log.

VER-1.3 The restore time is the start of the 30-minute stable period. Worked example: KPIs are normal from 14:20 and still normal at 14:50, so service was restored at 14:20.

### VER-2 Closing an incident

VER-2.1 Close an incident only when the cause is repaired, or when a temporary fix, such as traffic on a protection link, is covered by a problem record owned by the Problem Manager (NES-8).

VER-2.2 After a manual protection switch, move traffic back to the repaired link in a window agreed with the Change Manager.

### VER-3 Repeat incidents

VER-3.1 An incident is a repeat when it affects the same link, hub or router as another incident in the last 30 days.

VER-3.2 For a repeat incident, open a problem record (NES-8), check the earlier incident's review actions and escalate any that are overdue, and tell the Care Operations Lead (BUL-3.2).

### VER-4 Post-incident review

VER-4.1 Every Sev-1 and Sev-2 incident gets a post-incident review within 5 business days of the restore time.

VER-4.2 Reviews are blameless: they name roles, not people. Every action has an owner role and a due date.

## BUL — Status bulletin and communication

### BUL-1 The status bulletin

BUL-1.1 AW4_Network_Status_Snapshot is the status bulletin that Customer Care reads (OUT-1.1 in AW2). The NOC owns it.

BUL-1.2 Update AW4 within 15 minutes of any change to the status, ETR or CreditEligible, and at least at the SEV-2.1 cadence.

BUL-1.3 Each update sets the Status, Last updated, the ETR or restored time, Duration, CreditEligible, CustomerMessage and the region summary line.

### BUL-2 Customer wording

BUL-2.1 Write the CustomerMessage in plain language: an apology, what customers notice, the ETR as an estimate and, while the incident is open, the offer of an SMS update.

BUL-2.2 Never include the cause, equipment or link names, suppliers, contractors or blame, and never give a restore time without an engineering plan. Customer Care follows the same rules (OUT-3 and COM-4 in AW2).

BUL-2.3 Use these wording patterns and fill in the brackets.

| Status | CustomerMessage pattern |
|---|---|
| Restoring | "We're sorry. Some customers in [region] have [what customers notice]. Our engineers are restoring service, and we estimate it will be back to normal by [ETR] today. We'll send you an SMS when it's fixed." |
| Restored | "[Service] in [region] was restored at [time] on [date]. We're sorry for the disruption." |

### BUL-3 Internal updates

BUL-3.1 For Sev-1 and Sev-2 incidents, send the Care Operations Lead every bulletin update.

BUL-3.2 For a repeat incident, tell the Care Operations Lead the region and incident IDs so that Customer Care can flag retention reviews (SRV-4.1 in AW2).

## NES — NOC escalation matrix

| ID | Situation | Escalate to | How | Target response |
|---|---|---|---|---|
| NES-1 | A question that the NOC files don't answer | NOC Shift Manager | NOC bridge chat | 15 minutes |
| NES-2 | A Medium-risk action needs approval | NOC Shift Manager | Approval request (CHG-6) | 15 minutes |
| NES-3 | A High-risk action, or a Sev-1 incident | Head of Network Operations | Phone | 15 minutes |
| NES-4 | A physical fault on a site, link or splice | Field Operations | Field dispatch | Field team on site within 90 minutes |
| NES-5 | A transport fault that RBK-1 doesn't resolve | Transport Engineering (on call) | Phone | 30 minutes |
| NES-6 | An SMS centre queue that doesn't clear within 20 minutes of ACT-05 | Core Engineering (on call) | Phone | 30 minutes |
| NES-7 | A change that conflicts with a freeze (CHG-5) | Change Manager | Change record | Same business day |
| NES-8 | A repeat incident, or a temporary fix that needs a problem record | Problem Manager | Problem record | 1 business day |
| NES-9 | A Sev-1 incident needs a public statement | Corporate Communications | Phone | 30 minutes |
